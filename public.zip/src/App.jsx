import React from "react";
import { Route, Routes } from "react-router-dom";
import Layout from "./layouts/Layout";
import "./App.css"
import SideBar from "./layouts/Sidebar/Sidebar";
import Users from "./pages/Users";
import Admin from "./pages/Admin";

const App = () => {
  return (
    <>
    <Routes>
      <Route path="/" element={<Layout />}>
          <Route index element={<Admin />} />
          <Route path="/users" element={<Users />} />
      </Route>
    </Routes>
    </>
  );
};

export default App;
