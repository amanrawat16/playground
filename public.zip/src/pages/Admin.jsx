import React from "react";
import { ArrowRight } from "lucide-react";
import { useForm } from "react-hook-form";
import DefaultLayout from "../layouts/DefaultLayout";

export default function Admin() {




  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm();

  const handleCreateClub = (data) => console.log(data);

  return (
    <section>
      <div className="flex items-center justify-center">
        <div className="w-1/2 mx-auto">
          <h2 className="text-center text-2xl font-bold leading-tight text-black my-2">
            Sign up to create club
          </h2>
          {/* <p className="mt-2 text-center text-base text-gray-600">
            Already have an account?{' '}
            <a
              href="#"
              title=""
              className="font-medium text-black transition-all duration-200 hover:underline"
            >
              Sign In
            </a>
          </p> */}
          <form className="w-full max-w-lg mt-5" onSubmit={handleSubmit(handleCreateClub)}>
          <div className="flex flex-wrap -mx-3 mb-6">
              <div className="w-full px-3">
                <label
                  className="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                  htmlFor="clubName"
                >
                  Club Name
                </label>
                <input
                  className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                  id="grid-password"
                  type="text"
                  placeholder="Enter Club Name"
                  {
                    ...register("clubName",{
                      required:{
                        value:true,
                        message:"Club Name is required"
                      }
                    })
                  }
                />
                 <p className="text-red-500 text-xs italic">
                  {errors?.clubName?.message}
                </p>
              </div>
            </div>
            <div className="flex flex-wrap -mx-3 mb-6">
              <div className="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                <label
                  className="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                  htmlFor="grid-first-name"
                >
                  Club Admin Email
                </label>
                <input
                  className="appearance-none block w-full bg-gray-200 text-gray-700  rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white"
                  id="adminEmail"
                  type="email"
                  placeholder="Enter club admin emal"
                  {
                    ...register("adminEmail",{
                      required:{
                        value:true,
                        message:"Admin email is required"
                      }
                    })
                  }
                />
                <p className="text-red-500 text-xs italic">
                  {errors?.adminEmail?.message}
                </p>
              </div>
              <div className="w-full md:w-1/2 px-3">
                <label
                  className="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                  htmlFor="grid-last-name"
                >
                  Club Admin Password
                </label>
                <input
                  className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                  id="adminPass"
                  type="password"
                  placeholder="Enter Password"
                  {
                      ...register("adminPass",{
                        required:{
                          value:true,
                          message:"Admin Password is required"
                        }
                      })
                  }
                />
                 <p className="text-red-500 text-xs italic">
                  {errors?.adminPass?.message}.
                </p>
              </div>
            </div>
            <div className="flex flex-wrap -mx-3 mb-6">
              <div className="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                <label
                  className="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                  htmlFor="grid-first-name"
                >
                  Team Email
                </label>
                <input
                  className="appearance-none block w-full bg-gray-200 text-gray-700  rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white"
                  id="teamEmail"
                  type="email"
                  placeholder="Enter team email"
                  {
                    ...register("teamEmail",{
                      required:{
                        value:true,
                        message:"Team email is required"
                      }
                    })
                  }
                />
                <p className="text-red-500 text-xs italic">
                 {errors?.teamEmail?.message}.
                </p>
              </div>
              <div className="w-full md:w-1/2 px-3">
                <label
                  className="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2"
                  htmlFor="grid-last-name"
                >
                  Team Password Password
                </label>
                <input
                  className="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                  id="teamPass"
                  type="password"
                  placeholder="Enter Password"
                  {
                    ...register("teamPass",{
                      required:{
                        value:true,
                        message:"Team Password is required"
                      }
                    })
                  }
                />
                 <p className="text-red-500 text-xs italic">
                  {
                    errors?.teamPass?.message
                  }
                </p>
              </div>
            </div>
             <div className="submit_button">
              <button type="submit" className="px-2 py-3 bg-gray-800 text-white rounded-md w-full">Create Account</button>
             </div>
          </form>
        </div>
      </div>
    </section>
  );
}
